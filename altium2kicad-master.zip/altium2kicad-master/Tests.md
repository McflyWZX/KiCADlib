 
 Simple internal libraries with just one or two 3D
 - [x] A simple box only
 - [x] A simple box that is a larger
 - [x] A simple sphere
 - [x] A simple sphere that is a larger
 - [x] A simple cylinder
 - [x] A simple cylinder that is a larger
 - [x] 3 Pads and a simple box above them
 - [x] A simple box in yellow 
 - [x] A simple box in green
 - [x] A simple box in red with 50% transparency
 - [x] A simple box in red with 100% transparency
 - [ ] An extruded circle 
 - [ ] An extruded circle with standoff height 3 and total height 8
 - [x] An extruded rectangle with standoff height 1 and total height 8
 - [ ] An extruded oval with standoff height 3 and total height 9
 - [ ] An extruded circle with standoff height 3 and total height 8
 - [ ] An extruded circle with standoff height 3 and total height 8

 
