These foot prints are auto generate from lc_lib by the pcad library tool from XToolbox.org
